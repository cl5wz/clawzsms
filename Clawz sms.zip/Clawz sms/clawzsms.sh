clear
python .clawzsms.py
